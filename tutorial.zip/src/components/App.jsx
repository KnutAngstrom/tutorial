import { useState } from 'react';
import LoginPage from './LoginPage'
import WorkerPage from './WorkerPage'

export default function App() {
  const [loggedIn, setLoggedIn ] =  useState(false);
  console.log("Entering App()");
  function handleClick() {
  console.log("switch in callback()");
    setLoggedIn(!loggedIn)
  }
  
  return (
  <>
    <h3>React test app </h3>
      {loggedIn ? 
      <WorkerPage onClick={handleClick} />
      :
      <LoginPage onClick={handleClick} />
      }
  </>
    )
  }
